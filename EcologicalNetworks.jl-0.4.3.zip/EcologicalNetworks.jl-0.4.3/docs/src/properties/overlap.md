# Measures of overlap

```@docs
overlap
AJS
EAJS
```
