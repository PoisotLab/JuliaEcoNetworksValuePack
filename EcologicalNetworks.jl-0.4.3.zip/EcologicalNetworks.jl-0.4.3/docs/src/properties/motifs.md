# Motif enumeration

## List of canonical motifs

```@docs
unipartitemotifs
```

## Motif counting

```@docs
find_motif
```

## Probabilistic case

```@docs
expected_motif_count
```
