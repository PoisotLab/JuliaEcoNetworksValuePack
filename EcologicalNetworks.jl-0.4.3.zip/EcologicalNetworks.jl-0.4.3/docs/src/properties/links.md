# Links, degree, connectance

## Connectance and number of links

```@docs
sum
links
connectance
linkage_density
```

## Degree

```@docs
degree
```

```@docs
degree_var
```

## Species without interactions

```@docs
isdegenerate
simplify!
simplify
```

## Species-level specificity

```@docs
specificity
```
