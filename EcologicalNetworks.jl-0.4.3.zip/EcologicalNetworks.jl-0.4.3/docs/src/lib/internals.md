# Internals

```@autodocs
Modules = [EcologicalNetworks]
Private = true
Public = false
Order = [:function]
```
