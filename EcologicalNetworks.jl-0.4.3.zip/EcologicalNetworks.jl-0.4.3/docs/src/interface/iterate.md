Ecological networks types follow the iteration interface, allowing them to be
used within a loop. Iteration is done on *interactions* (species are already
arrays), and return a named tuple with various information.

## Network length

```@docs
length
```

## Iteration

```@docs
iterate
```