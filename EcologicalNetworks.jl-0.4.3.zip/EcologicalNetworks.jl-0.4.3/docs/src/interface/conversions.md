Conversions between types are used to perform two usual operations: make a
bipartite network unipartite, and remove quantitative information. There are two
high-level functions which work by using the union types, and a series of
type-to-type functions (the later should be avoided, and exists only to make the
high-level functions work).

```@docs
convert
```
