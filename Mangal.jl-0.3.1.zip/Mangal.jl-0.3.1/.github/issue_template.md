<!-- Thank you for opening an issue! If your issue is about a question, or a
suggestion, please replace all of the content between curly brackets, {like so},
by the appropriate information. If your issue is a more technical point, or a
suggestion for improvement, feel free to remove all of this and just write as
usual. -->

{short description of the problem}

{what you were trying to do}

```julia
# Please put the relevant code here
```

{what you expected to see}

{what you got instead}

---

Using {operating system}, Julia {version}, EcologicalNetwork {version}

{any additional information}
