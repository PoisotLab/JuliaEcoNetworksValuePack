# This will use the  MANGAL_BEARER_TOKEN variable on the Travis build

# Mangal.login()
